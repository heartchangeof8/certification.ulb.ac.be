package com.example.oxygen;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;

public class PIECE {
    private String numTypePiece;
    private String typePiece;
    private String nom;
    private String format;
    private String idGed;
    private String numTechDocCli;

    @XmlElement(name = "NUMTYPEPIECE")
    public String getNumTypePiece() { return numTypePiece; }
    public void setNumTypePiece(String numTypePiece) { this.numTypePiece = numTypePiece; }

    @XmlElement(name = "TYPEPIECE")
    public String getTypePiece() { return typePiece; }
    public void setTypePiece(String typePiece) { this.typePiece = typePiece; }

    @XmlElement(name = "NOM")
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }

    @XmlElement(name = "FORMAT")
    public String getFormat() { return format; }
    public void setFormat(String format) { this.format = format; }

    @XmlElement(name = "IDGED")
    public String getIdGed() { return idGed; }
    public void setIdGed(String idGed) { this.idGed = idGed; }

    @XmlElement(name = "NUMTECHDOCCLI")
    public String getNumTechDocCli() { return numTechDocCli; }
    public void setNumTechDocCli(String numTechDocCli) { this.numTechDocCli = numTechDocCli; }
}
