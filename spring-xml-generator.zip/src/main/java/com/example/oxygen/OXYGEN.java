package com.example.oxygen;

import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "OXYGEN")
public class OXYGEN {
    private DOSSIER dossier;
    private List<PIECE> pieces;

    @XmlElement(name = "DOSSIER")
    public DOSSIER getDossier() { return dossier; }
    public void setDossier(DOSSIER dossier) { this.dossier = dossier; }

    @XmlElement(name = "PIECE")
    public List<PIECE> getPieces() { return pieces; }
    public void setPieces(List<PIECE> pieces) { this.pieces = pieces; }
}
