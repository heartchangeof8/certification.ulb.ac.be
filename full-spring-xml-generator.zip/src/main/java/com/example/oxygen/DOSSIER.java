package com.example.oxygen;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;

public class DOSSIER {
    private String rib;
    private String crep;
    private String codeFiliere;
    private String referenceDossier;
    private String idOperateur;
    private String typeCanal;
    private String idPersonne;
    private String xsdoxyversion;

    @XmlElement(name = "RIB")
    public String getRib() { return rib; }
    public void setRib(String rib) { this.rib = rib; }

    @XmlElement(name = "CREP")
    public String getCrep() { return crep; }
    public void setCrep(String crep) { this.crep = crep; }

    @XmlElement(name = "CODEFILIERE")
    public String getCodeFiliere() { return codeFiliere; }
    public void setCodeFiliere(String codeFiliere) { this.codeFiliere = codeFiliere; }

    @XmlElement(name = "REFERENCEDOSSIER")
    public String getReferenceDossier() { return referenceDossier; }
    public void setReferenceDossier(String referenceDossier) { this.referenceDossier = referenceDossier; }

    @XmlElement(name = "IDOPERATEUR")
    public String getIdOperateur() { return idOperateur; }
    public void setIdOperateur(String idOperateur) { this.idOperateur = idOperateur; }

    @XmlElement(name = "TYPECANAL")
    public String getTypeCanal() { return typeCanal; }
    public void setTypeCanal(String typeCanal) { this.typeCanal = typeCanal; }

    @XmlElement(name = "IDPERSONNE")
    public String getIdPersonne() { return idPersonne; }
    public void setIdPersonne(String idPersonne) { this.idPersonne = idPersonne; }

    @XmlAttribute(name = "xsdoxyversion")
    public String getXsdoxyversion() { return xsdoxyversion; }
    public void setXsdoxyversion(String xsdoxyversion) { this.xsdoxyversion = xsdoxyversion; }
}
