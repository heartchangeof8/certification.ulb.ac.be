package com.example.service;

import com.example.oxygen.*;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import org.springframework.stereotype.Service;

import java.io.StringWriter;
import java.util.Collections;

@Service
public class XmlService {
    public String convertToXml(OXYGEN oxygen) {
        try {
            JAXBContext context = JAXBContext.newInstance(OXYGEN.class);
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

            StringWriter sw = new StringWriter();
            marshaller.marshal(oxygen, sw);
            return sw.toString();
        } catch (JAXBException e) {
            e.printStackTrace();
            return "Error generating XML";
        }
    }

    public OXYGEN createSampleData() {
        OXYGEN oxygen = new OXYGEN();
        DOSSIER dossier = new DOSSIER();
        dossier.setRib("1234567890123");
        dossier.setReferenceDossier("REF12345");
        dossier.setCodeFiliere("100");
        dossier.setIdOperateur("OPER01");
        dossier.setTypeCanal("A");
        dossier.setXsdoxyversion("1.0");

        PIECE piece = new PIECE();
        piece.setNom("document.pdf");
        piece.setFormat("PDF");

        oxygen.setDossier(dossier);
        oxygen.setPieces(Collections.singletonList(piece));

        return oxygen;
    }
}
