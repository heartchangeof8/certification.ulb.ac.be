package com.example.controller;

import com.example.oxygen.OXYGEN;
import com.example.service.XmlService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/oxygen")
public class OxygenController {
    private final XmlService xmlService;

    public OxygenController(XmlService xmlService) {
        this.xmlService = xmlService;
    }

    @GetMapping("/generate")
    public String generateXml() {
        OXYGEN oxygen = xmlService.createSampleData();
        return xmlService.convertToXml(oxygen);
    }
}
