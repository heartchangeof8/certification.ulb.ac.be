package com.example.oxygen;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.StringWriter;
import java.util.Collections;

@SpringBootApplication
public class OxygenApplication {
    public static void main(String[] args) {
        SpringApplication.run(OxygenApplication.class, args);
    }
}

@RestController
@RequestMapping("/oxygen")
class OxygenController {
    @GetMapping("/generate")
    public String generateXml() throws JAXBException {
        REQUEST request = new REQUEST();
        request.setOperation("Prepare");
        request.setxId("CAWL20250319155700001");
        
        DOSSIER dossier = new DOSSIER();
        dossier.setRib("002600000011Y");
        dossier.setCodeFiliere("CAWL");
        dossier.setReferenceDossier("90000786800");
        dossier.setIdOperateur("CAWL");
        dossier.setTypeCanal("T");
        request.setDossier(dossier);
        
        PIECE piece = new PIECE();
        piece.setTypePiece("628");
        piece.setNom("PieceTechniqueDeclenchante.txt");
        piece.setFormat("TXT");
        request.setPieces(Collections.singletonList(piece));
        
        JAXBContext context = JAXBContext.newInstance(REQUEST.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        marshaller.setProperty(Marshaller.JAXB_ENCODING, "ISO-8859-1");
        
        StringWriter sw = new StringWriter();
        marshaller.marshal(request, sw);
        
        return sw.toString();
    }
}
