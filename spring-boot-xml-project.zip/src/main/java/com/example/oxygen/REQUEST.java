package com.example.oxygen;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;
import java.util.List;

@XmlRootElement(name = "REQUEST")
public class REQUEST {
    private String operation;
    private String xId;
    private DOSSIER dossier;
    private List<PIECE> pieces;

    @XmlAttribute(name = "operation")
    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    @XmlAttribute(name = "xId")
    public String getxId() {
        return xId;
    }

    public void setxId(String xId) {
        this.xId = xId;
    }

    @XmlElement(name = "DOSSIER")
    public DOSSIER getDossier() {
        return dossier;
    }

    public void setDossier(DOSSIER dossier) {
        this.dossier = dossier;
    }

    @XmlElement(name = "PIECE")
    public List<PIECE> getPieces() {
        return pieces;
    }

    public void setPieces(List<PIECE> pieces) {
        this.pieces = pieces;
    }
}
