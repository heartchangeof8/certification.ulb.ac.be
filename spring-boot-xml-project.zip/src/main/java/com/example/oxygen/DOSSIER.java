package com.example.oxygen;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "DOSSIER")
public class DOSSIER {
    private String rib;
    private String codeFiliere;
    private String referenceDossier;
    private String idOperateur;
    private String typeCanal;

    @XmlAttribute(name = "rib")
    public String getRib() {
        return rib;
    }

    public void setRib(String rib) {
        this.rib = rib;
    }

    @XmlAttribute(name = "codefiliere")
    public String getCodeFiliere() {
        return codeFiliere;
    }

    public void setCodeFiliere(String codeFiliere) {
        this.codeFiliere = codeFiliere;
    }

    @XmlAttribute(name = "referenceDossier")
    public String getReferenceDossier() {
        return referenceDossier;
    }

    public void setReferenceDossier(String referenceDossier) {
        this.referenceDossier = referenceDossier;
    }

    @XmlAttribute(name = "idoperateur")
    public String getIdOperateur() {
        return idOperateur;
    }

    public void setIdOperateur(String idOperateur) {
        this.idOperateur = idOperateur;
    }

    @XmlAttribute(name = "typeCanal")
    public String getTypeCanal() {
        return typeCanal;
    }

    public void setTypeCanal(String typeCanal) {
        this.typeCanal = typeCanal;
    }
}
